from __future__ import print_function


def hello():
    print('hello, from baz')
